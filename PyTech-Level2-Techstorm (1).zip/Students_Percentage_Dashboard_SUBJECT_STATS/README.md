Students Percentage Dashboard

Dataset columns preserved:
math score, readingݫ reading score, writing score

Run:
python main.py

Open:
http://localhost:8000
