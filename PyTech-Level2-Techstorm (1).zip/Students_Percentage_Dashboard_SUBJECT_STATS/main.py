# main.py
from http.server import SimpleHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from model import MarksAnalyzer

analyzer = MarksAnalyzer("marks.csv","data.txt")

class AppHandler(SimpleHTTPRequestHandler):

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/":
            self.send_html("index.html")

        elif parsed.path == "/load":
            analyzer.load_data()
            self.redirect("/table")

        elif parsed.path == "/average":
            avg = analyzer.get_average()
            self.send_dynamic("average.html", {"{{RESULT}}": str(avg)})

        elif parsed.path == "/subjects":
            stats = analyzer.get_subject_high_low()
            html_data = ""
            for k,v in stats.items():
                html_data += f"<p><b>{k.title()}</b> → Highest: {v['high']} | Lowest: {v['low']}</p>"
            self.send_dynamic("subjects.html", {"{{SUBJECT_STATS}}": html_data})

        elif parsed.path == "/table":
            rows = analyzer.get_table_rows()
            self.send_dynamic("table.html", {"{{ROWS}}": rows})
        else:
            super().do_GET()

    def send_html(self, file):
        with open(file,"rb") as f:
            content=f.read()
        self.send_response(200)
        self.send_header("Content-type","text/html")
        self.end_headers()
        self.wfile.write(content)

    def send_dynamic(self, file, rep):
        with open(file,"r",encoding="utf-8") as f:
            html=f.read()
        for k,v in rep.items():
            html=html.replace(k,v)
        self.send_response(200)
        self.send_header("Content-type","text/html")
        self.end_headers()
        self.wfile.write(html.encode())

    def redirect(self,loc):
        self.send_response(302)
        self.send_header("Location",loc)
        self.end_headers()

if __name__=="__main__":
    PORT=8000
    print(f"Open http://localhost:{PORT}")
    HTTPServer(("localhost",PORT),AppHandler).serve_forever()
