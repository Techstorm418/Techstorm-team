# model.py
import pandas as pd

class MarksAnalyzer:

    def __init__(self, csv_file, log_file):
        self.csv_file = csv_file
        self.log_file = log_file
        self.df = None

    def log(self, text):
        with open(self.log_file, "a") as f:
            f.write(text + "\n")

    # ===== LOAD DATA =====
    def load_data(self):
        self.df = pd.read_csv(self.csv_file)

        # 🔥 IMPORTANT FIX → reset index so students start from 1
        self.df = self.df.reset_index(drop=True)

        self.log("Dataset loaded")

    # ===== AVERAGE =====
    def get_average(self):
        if self.df is None:
            return "Load dataset first"

        avg = (
            (self.df["math score"] +
             self.df["reading score"] +
             self.df["writing score"]) / 3
        ).mean()

        return round(avg, 2)

    # ===== SUBJECT HIGH & LOW =====
    def get_subject_high_low(self):
        if self.df is None:
            return {}

        result = {}

        for sub in ["math score", "reading score", "writing score"]:
            high = self.df[sub].max()
            low = self.df[sub].min()

            result[sub] = {
                "high": round(high, 2),
                "low": round(low, 2)
            }

        return result

    # ===== TABLE ROWS =====
    def get_table_rows(self):

        if self.df is None:
            return "<tr><td colspan='4'>Load dataset first</td></tr>"

        rows = ""

        # 🔥 FINAL FIX → enumerate creates Student 1,2,3...
        for i, (_, r) in enumerate(self.df.iterrows(), start=1):

            rows += f"""
            <tr>
                <td>Student {i}</td>
                <td>{r['math score']}</td>
                <td>{r['reading score']}</td>
                <td>{r['writing score']}</td>
            </tr>
            """

        return rows