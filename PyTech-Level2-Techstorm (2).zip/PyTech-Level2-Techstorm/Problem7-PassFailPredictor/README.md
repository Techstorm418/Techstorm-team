# 🎓 Pass/Fail Predictor – ML Classification Project

## 📌 Overview
This project predicts whether a student will PASS or FAIL based on:
- Math Score
- Reading Score
- Writing Score

The system uses Machine Learning Classification models built using Scikit-Learn.

## 🚀 Technologies Used
- Python 3.x
- Flask (Web Framework)
- Pandas (Data Processing)
- Scikit-Learn (ML Models)
- NumPy

## 🧠 ML Models Used
- Logistic Regression
- Decision Tree Classifier

The best model is automatically selected based on accuracy.


## 📂 Project Structure