from flask import Flask, render_template, request
from model import train_model, predict_result
import webbrowser
app = Flask(__name__)
# Train model once when app starts
model = train_model()

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None

    if request.method == "POST":
        math = float(request.form["math"])
        reading = float(request.form["reading"])
        writing = float(request.form["writing"])

        prediction = predict_result(model, math, reading, writing)

    return render_template("index.html", prediction=prediction, accuracy=accuracy)

if __name__ == "__main__":
    model, accuracy = train_model()
    webbrowser.open("http://127.0.0.1:5000/")
    app.run(debug=False)