
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score


def train_model():

    df = pd.read_csv("studentperfomance.csv")

    df["average"] = (
        df["math score"] +
        df["reading score"] +
        df["writing score"]
    ) / 3

    df["result"] = df["average"].apply(lambda x: 1 if x >= 40 else 0)

    X = df[["math score", "reading score", "writing score"]]
    y = df["result"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    # Logistic Regression
    log_model = LogisticRegression()
    log_model.fit(X_train, y_train)
    log_pred = log_model.predict(X_test)
    log_acc = accuracy_score(y_test, log_pred)

    # Decision Tree
    tree_model = DecisionTreeClassifier()
    tree_model.fit(X_train, y_train)
    tree_pred = tree_model.predict(X_test)
    tree_acc = accuracy_score(y_test, tree_pred)

    print("Logistic Regression Accuracy:", round(log_acc * 100, 2), "%")
    print("Decision Tree Accuracy:", round(tree_acc * 100, 2), "%")

    # Select Best Model
    if log_acc >= tree_acc:
        print("Selected Model: Logistic Regression")
        return log_model, round(log_acc * 100, 2)
    else:
        print("Selected Model: Decision Tree")
        return tree_model, round(tree_acc * 100, 2)

def predict_result(model, math, reading, writing):

    sample = pd.DataFrame(
        [[math, reading, writing]],
        columns=["math score", "reading score", "writing score"]
    )

    prediction = model.predict(sample)

    if prediction[0] == 1:
        return "PASS"
    else:
        return "FAIL"